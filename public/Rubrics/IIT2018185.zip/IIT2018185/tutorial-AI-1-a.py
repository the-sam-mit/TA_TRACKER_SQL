
# coding: utf-8

# In[1]:


import numpy as np


# In[24]:


class Environment:
    row=0
    col=0
    grid = []
    def __init__(self,row,col):
        self.row = row
        self=col = col
        grid = []
        for r in range(row):
            tempRow = []
            for c in range(col):
                tempRow.append(1)
            grid.append(tempRow)


# In[25]:


class Agent:
    x = 0
    y = 0
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def moveup(self):
        self.y = self.y+1
    def movedown(self):
        self.y = self.y-1
    def moveleft(self):
        self.x = self.x-1
    def moveright(self):
        self.x = self.x+1


# In[17]:


# input row, col, start, goal
row,col   = map(int,input("Enter m,n : ").split())
srcX,srcY = map(int,input('Enter Start Pos: ').split())
desX,desY = map(int,input('Enter Goal Pos: ').split())


# In[26]:


# init env, agent
env   = Environment(row,col)
agent = Agent(srcX,srcY)


# In[27]:


# simulating
print(agent.x,agent.y)

while(agent.x != desX):
    if(agent.x > desX):
        agent.moveleft()
    if(agent.x < desX):
        agent.moveright()
    print(agent.x,agent.y)
        
while(agent.y != desY):
    if(agent.y > desY):
        agent.movedown()
    if(agent.y < desY):
        agent.moveup()
    print(agent.x,agent.y)
print(agent.x,agent.y)

