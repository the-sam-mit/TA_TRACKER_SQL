
# coding: utf-8

# In[31]:


import numpy as np
import sys


# In[37]:


class Environment:
    row=0
    col=0
    grid = []
    __goalx = 0
    __goaly = 0
    def __init__(self,row,col,goalx,goaly):
        self.row = row
        self.col = col
        grid = []
        self.goalx = goalx
        self.goaly = goaly
        for r in range(row):
            tempRow = []
            for c in range(col):
                tempRow.append(1)
            grid.append(tempRow)


# In[38]:


class Agent:
    __x = 0
    __y = 0
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def calcDistance(self,env):
        return abs(self.x-env.goalx)+abs(self.y-env.goaly)
    def getCord(self):
        return (self.x,self.y)
    def moveup(self):
        self.y = self.y+1
    def movedown(self):
        self.y = self.y-1
    def moveleft(self):
        self.x = self.x-1
    def moveright(self):
        self.x = self.x+1


# In[39]:


# input row, col, start, goal
row,col   = map(int,input("Enter m,n : ").split())
srcX,srcY = map(int,input('Enter Start Pos: ').split())
desX,desY = map(int,input('Enter Goal Pos: ').split())


# In[40]:


# init env, agent
env   = Environment(row,col,desX,desY)
agent = Agent(srcX,srcY)


# In[41]:


# simulating
print(agent.getCord())
while(agent.calcDistance(env) != 0):
    x,y = agent.getCord()
    move = ""
    dist = agent.calcDistance(env)
    #     check up
    agent.moveup()
    if(dist > agent.calcDistance(env)):
        dist = agent.calcDistance(env)
        move = "u"
    agent.movedown()
    #     check down
    agent.movedown()
    if(dist > agent.calcDistance(env)):
        dist = agent.calcDistance(env)
        move = "d"
    agent.moveup()
    #     check left
    agent.moveleft()
    if(dist > agent.calcDistance(env)):
        dist = agent.calcDistance(env)
        move = "l"
    agent.moveright()
    #     check right
    agent.moveright()
    if(dist > agent.calcDistance(env)):
        dist = agent.calcDistance(env)
        move = "r"
    agent.moveleft()
    
#     final movement
    if(move == 'u'):
        agent.moveup()
    if(move == 'd'):
        agent.movedown()
    if(move == 'l'):
        agent.moveleft()
    if(move == 'r'):
        agent.moveright()
    print(agent.getCord())

